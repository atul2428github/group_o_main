package com.admin.test;

public class Product {

}
